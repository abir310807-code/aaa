# Roadmap
- [x] Mobile on-screen buttons
- [x] Level 4 — Halka Shamsu & Pistol Jewel vs Dokander Akkash (salam sound, lathi/chada choice, chase)
- [x] Level 5 — The Foothpath: rickshaw crash, hawker argument, timed car hit, Footpath Card
- [x] Replace Level 5 car song and verify two-second lead, five-second drive, and full road exit.
