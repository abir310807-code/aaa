<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture
- Game touch controls remain visible regardless of pointer type so phones, tablets, and hybrid devices can use the same actions.
- Game rules and cinematics live in plain TypeScript under `src/game`; level sequences implement `src/game/sequence.ts` so per-frame state stays outside React.
- Cinematic audio timing uses wall-clock timestamps rather than clamped frame deltas, keeping sound and visuals synchronized on slow renderers.
