// Synthesized WebAudio. Peak gains kept low (~-12dB ceiling = 0.25).
import { getAudioSettings, type AudioSettings } from "./storage";

let ctx: AudioContext | null = null;
let master: GainNode, sfx: GainNode, music: GainNode;
let ambientStop: (() => void) | null = null;

function ensure() {
  if (ctx) return ctx;
  ctx = new AudioContext();
  master = ctx.createGain();
  sfx = ctx.createGain();
  music = ctx.createGain();
  sfx.connect(master);
  music.connect(master);
  master.connect(ctx.destination);
  applySettings(getAudioSettings());
  return ctx;
}

export function applySettings(s: AudioSettings) {
  if (!ctx) return;
  master.gain.value = s.muted ? 0 : s.master * 0.25;
  sfx.gain.value = s.sfx;
  music.gain.value = s.music;
}

export function unlockAudio() {
  const c = ensure();
  if (c.state === "suspended") void c.resume();
}

function tone(freq: number, dur: number, type: OscillatorType = "square", vol = 0.5, slideTo?: number, delay = 0) {
  const c = ensure();
  const t = c.currentTime + delay;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(g).connect(sfx);
  o.start(t);
  o.stop(t + dur + 0.02);
}

function noise(dur: number, vol: number, filterHz: number, dest?: AudioNode) {
  const c = ensure();
  const buf = c.createBuffer(1, Math.floor(c.sampleRate * dur), c.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  const src = c.createBufferSource();
  src.buffer = buf;
  const f = c.createBiquadFilter();
  f.type = "lowpass";
  f.frequency.value = filterHz;
  const g = c.createGain();
  g.gain.setValueAtTime(vol, c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + dur);
  src.connect(f).connect(g).connect(dest ?? sfx);
  src.start();
}

export const sound = {
  click: () => tone(660, 0.06, "square", 0.3),
  hover: () => tone(1200, 0.03, "sine", 0.15),
  step: () => {
    const p = 0.9 + Math.random() * 0.2;
    tone(90 * p, 0.08, "sine", 0.55, 50); // heel thud
    noise(0.09, 0.45, 1800 * p); // sole scuff
  },
  blip: (pitch: number) => tone(pitch, 0.04, "square", 0.2),
  fanfare: () => [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.25, "triangle", 0.4, undefined, i * 0.1)),
  gunshot: () => { noise(0.35, 0.9, 4000); tone(120, 0.25, "sine", 0.8, 40); },
  crash: () => { noise(0.55, 0.9, 2600); tone(95, 0.45, "sawtooth", 0.7, 35); tone(240, 0.18, "square", 0.3, 80, 0.03); },
  launch: () => { noise(0.7, 0.65, 5000); tone(130, 0.65, "sawtooth", 0.55, 620); },
  wind: () => {
    const c = ensure();
    const t = c.currentTime;
    const dur = 5.2;
    const buf = c.createBuffer(1, Math.floor(c.sampleRate * dur), c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const src = c.createBufferSource();
    src.buffer = buf;
    const f = c.createBiquadFilter();
    f.type = "bandpass";
    f.Q.value = 1.2;
    f.frequency.setValueAtTime(300, t);
    f.frequency.exponentialRampToValueAtTime(1400, t + dur * 0.45);
    f.frequency.exponentialRampToValueAtTime(250, t + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.001, t);
    g.gain.exponentialRampToValueAtTime(0.7, t + dur * 0.4);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    // trembling: tremolo LFO on a second gain stage
    const trem = c.createGain();
    trem.gain.value = 0.6;
    const lfo = c.createOscillator();
    lfo.frequency.setValueAtTime(7, t);
    lfo.frequency.linearRampToValueAtTime(11, t + dur);
    const depth = c.createGain();
    depth.gain.value = 0.4;
    lfo.connect(depth).connect(trem.gain);
    src.connect(f).connect(g).connect(trem).connect(sfx);
    src.start(t);
    lfo.start(t);
    src.stop(t + dur);
    lfo.stop(t + dur);
  },
  sting: () => [392, 523].forEach((f, i) => tone(f, 0.3, "triangle", 0.4, undefined, i * 0.12)),
};

/** Warm-morning bed: soft filtered noise "air" + slow chirps. */
export function startAmbient() {
  const c = ensure();
  stopAmbient();
  const air = c.createBufferSource();
  const buf = c.createBuffer(1, c.sampleRate * 2, c.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  air.buffer = buf;
  air.loop = true;
  const f = c.createBiquadFilter();
  f.type = "lowpass";
  f.frequency.value = 400;
  const g = c.createGain();
  g.gain.value = 0.08;
  air.connect(f).connect(g).connect(music);
  air.start();
  const chirp = window.setInterval(() => {
    if (Math.random() < 0.5) {
      const base = 2200 + Math.random() * 900;
      const o = c.createOscillator();
      const cg = c.createGain();
      o.frequency.setValueAtTime(base, c.currentTime);
      o.frequency.exponentialRampToValueAtTime(base * 1.4, c.currentTime + 0.08);
      cg.gain.setValueAtTime(0.06, c.currentTime);
      cg.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.1);
      o.connect(cg).connect(music);
      o.start();
      o.stop(c.currentTime + 0.12);
    }
  }, 1400);
  ambientStop = () => {
    air.stop();
    clearInterval(chirp);
  };
}
export function stopAmbient() {
  ambientStop?.();
  ambientStop = null;
}
