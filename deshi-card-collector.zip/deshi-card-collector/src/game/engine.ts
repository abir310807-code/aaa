// Level runtime: renderer, player, characters, input, collision, interaction.
import * as THREE from "three";
import type { CharacterDef } from "./types";
import { sound } from "./audio";
import type { SequenceFactory } from "./sequence";

export interface Collider { x: number; z: number; hw: number; hd: number }

export const SPEED = 3.2;
export const TALK_RADIUS = 2;
const PLAYER_R = 0.35;
const BOUNDS = { minX: -10, maxX: 10, minZ: -4.4, maxZ: 6 };

export interface RuntimeCallbacks {
  onPrompt: (p: { id: string; x: number; y: number } | null) => void;
  onTalk: (id: string) => void;
  onSequenceEvent: (event: string) => void;
}

export interface RuntimeOptions {
  playerStart?: [number, number] | undefined;
  sequence?: SequenceFactory | undefined;
}

export interface Runtime {
  dispose: () => void;
  setPaused: (p: boolean) => void;
  setJoystick: (x: number, y: number) => void;
  talk: () => void;
  /** Muzzle flash at the player. */
  flash: () => void;
  /** NPCs flee away from the player and leave the scene. */
  scatter: () => void;
  /** Player shoulders the first NPC and walks off-screen. */
  carry: () => void;
  /** Chaser grabs a weapon and chases the player + other NPCs off to the right. */
  chase: (chaserId: string, weapon: "stick" | "protractor") => void;
  startSequence: () => void;
  resumeSequence: () => void;
  readyEl: HTMLElement;
}

function capsule(color: string) {
  const g = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({ color, flatShading: true });
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.32, 0.9, 6), mat);
  body.position.y = 0.65;
  const head = new THREE.Mesh(new THREE.IcosahedronGeometry(0.24, 0), new THREE.MeshLambertMaterial({ color: "#f1c9a5", flatShading: true }));
  head.position.y = 1.35;
  const nose = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.12), mat);
  nose.position.set(0, 1.35, 0.24);
  g.add(body, head, nose);
  return g;
}

function pole(color: string) {
  const g = new THREE.Group();
  const mat = new THREE.MeshLambertMaterial({ color, flatShading: true });
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 4.4, 6), mat);
  shaft.position.y = 2.2;
  const arm = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.1, 0.1), new THREE.MeshLambertMaterial({ color: "#3a3a3a" }));
  arm.position.y = 4.1;
  const tf = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 0.35), new THREE.MeshLambertMaterial({ color: "#4f5a52", flatShading: true }));
  tf.position.set(0, 3.5, 0.2);
  const sign = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.2, 0.02), new THREE.MeshLambertMaterial({ color: "#f2d23a" }));
  sign.position.set(0, 1.6, 0.13);
  g.add(shaft, arm, tf, sign);
  return g;
}

export function createRuntime(
  host: HTMLElement,
  build: (s: THREE.Scene) => Collider[],
  chars: CharacterDef[],
  cb: RuntimeCallbacks,
  options: RuntimeOptions = {},
): Runtime {
  const renderer = new THREE.WebGLRenderer({ antialias: false });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
  renderer.setSize(host.clientWidth, host.clientHeight);
  host.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const colliders = build(scene);
  const camera = new THREE.PerspectiveCamera(45, host.clientWidth / host.clientHeight, 0.1, 60);

  const player = capsule("#2e4a7a");
  player.position.set(options.playerStart?.[0] ?? 0, 0, options.playerStart?.[1] ?? 3.5);
  player.rotation.y = Math.PI;
  scene.add(player);

  const npcs = chars.map((c) => {
    const m = c.kind === "pole" ? pole(c.color) : capsule(c.color);
    m.position.set(c.pos[0], 0, c.pos[1]);
    m.rotation.y = c.facing;
    scene.add(m);
    colliders.push({ x: c.pos[0], z: c.pos[1], hw: 0.3, hd: 0.3 });
    return { def: c, mesh: m, gesture: 0, flee: null as null | { x: number; z: number } };
  });
  let carrying = false;
  let chasing = false;
  let chaserMesh: THREE.Object3D | null = null;
  const sequence = options.sequence?.({
    scene,
    player,
    npcs: new Map(npcs.map((n) => [n.def.id, n.mesh])),
    onEvent: cb.onSequenceEvent,
  });
  let sequenceReady = !sequence?.ready;
  if (sequence?.ready) void sequence.ready.finally(() => { sequenceReady = true; });

  const keys = new Set<string>();
  const joy = { x: 0, y: 0 };
  let paused = false;
  let nearest: string | null = null;
  let stepT = 0;
  let lookOffset = 0; // mouse-look-lite: slight camera yaw from cursor
  let t = 0;
  const smoke: THREE.Object3D[] = [];
  scene.traverse((o) => { if (o.name === "smoke") smoke.push(o); });
  const muzzle = new THREE.PointLight("#fff1b0", 0, 8);
  scene.add(muzzle);

  const talk = () => {
    if (paused || !nearest) return;
    const n = npcs.find((n) => n.def.id === nearest);
    if (n) n.gesture = 1;
    cb.onTalk(nearest);
  };
  const kd = (e: KeyboardEvent) => {
    keys.add(e.code);
    if (e.code === "KeyE") talk();
  };
  const ku = (e: KeyboardEvent) => keys.delete(e.code);
  const mm = (e: MouseEvent) => { lookOffset = (e.clientX / window.innerWidth - 0.5) * 1.2; };
  const click = () => talk();
  const resize = () => {
    renderer.setSize(host.clientWidth, host.clientHeight);
    camera.aspect = host.clientWidth / host.clientHeight;
    camera.updateProjectionMatrix();
  };
  window.addEventListener("keydown", kd);
  window.addEventListener("keyup", ku);
  window.addEventListener("mousemove", mm);
  renderer.domElement.addEventListener("click", click);
  window.addEventListener("resize", resize);

  const blocked = (x: number, z: number) =>
    colliders.some((c) => Math.abs(x - c.x) < c.hw + PLAYER_R && Math.abs(z - c.z) < c.hd + PLAYER_R);

  const clock = new THREE.Clock();
  const tmp = new THREE.Vector3();
  const camTarget = new THREE.Vector3();
  let frames = 0;
  let raf = 0;

  const loop = () => {
    raf = requestAnimationFrame(loop);
    const dt = Math.min(clock.getDelta(), 0.05);
    t += dt;

    let mx = 0, mz = 0;
    if (!paused) {
      if (keys.has("KeyW") || keys.has("ArrowUp")) mz -= 1;
      if (keys.has("KeyS") || keys.has("ArrowDown")) mz += 1;
      if (keys.has("KeyA") || keys.has("ArrowLeft")) mx -= 1;
      if (keys.has("KeyD") || keys.has("ArrowRight")) mx += 1;
      mx += joy.x; mz += joy.y;
    }
    const len = Math.hypot(mx, mz);
    if (len > 0.1) {
      mx /= Math.max(len, 1); mz /= Math.max(len, 1);
      const nx = THREE.MathUtils.clamp(player.position.x + mx * SPEED * dt, BOUNDS.minX, BOUNDS.maxX);
      const nz = THREE.MathUtils.clamp(player.position.z + mz * SPEED * dt, BOUNDS.minZ, BOUNDS.maxZ);
      if (!blocked(nx, player.position.z)) player.position.x = nx;
      if (!blocked(player.position.x, nz)) player.position.z = nz;
      player.rotation.y = Math.atan2(mx, mz);
      player.children[0]!.position.y = 0.65 + Math.abs(Math.sin(t * 12)) * 0.06;
      stepT += dt;
      if (stepT > 0.32) { stepT = 0; sound.step(); }
    }
    if (chasing) {
      player.position.x += SPEED * 2 * dt;
      player.rotation.y = Math.PI / 2;
      player.position.y = Math.abs(Math.sin(t * 16)) * 0.15;
      const w = chaserMesh?.getObjectByName("weapon");
      if (w) w.rotation.z = Math.sin(t * 14) * 1.1;
    }
    if (carrying) {
      player.position.x += SPEED * 0.8 * dt;
      player.rotation.y = Math.PI / 2;
      player.children[0]!.position.y = 0.65 + Math.abs(Math.sin(t * 9)) * 0.08;
      stepT += dt;
      if (stepT > 0.4) { stepT = 0; sound.step(); }
    }


    // characters: idle sway + wave gesture
    let best: string | null = null, bestD = TALK_RADIUS;
    for (const o of smoke) { o.position.y += dt * 0.3; if (o.position.y > 4) o.position.y = 1.8; }
    muzzle.intensity = Math.max(0, muzzle.intensity - dt * 200);
    for (const n of npcs) {
      if (carrying) break;
      if (sequence?.controls(n.def.id)) continue;
      if (n.flee) {
        n.mesh.position.x += n.flee.x * SPEED * 2 * dt;
        n.mesh.position.z += n.flee.z * SPEED * 2 * dt;
        n.mesh.rotation.y = Math.atan2(n.flee.x, n.flee.z);
        n.mesh.position.y = Math.abs(Math.sin(t * 16)) * 0.15;
        if (Math.abs(n.mesh.position.x) > 16) n.mesh.visible = false;
        continue;
      }
      n.mesh.rotation.z = Math.sin(t * 1.6 + n.def.pos[0]) * 0.04;
      if (n.gesture > 0) {
        n.gesture = Math.max(0, n.gesture - dt);
        n.mesh.position.y = Math.sin((1 - n.gesture) * Math.PI * 3) * 0.12;
      }
      if (!n.mesh.visible) continue;
      const d = Math.hypot(n.mesh.position.x - player.position.x, n.mesh.position.z - player.position.z);
      if (d < bestD) { bestD = d; best = n.def.id; }
    }
    nearest = paused ? null : best;
    if (nearest) {
      const n = npcs.find((n) => n.def.id === nearest)!;
      tmp.set(n.mesh.position.x, 2.1, n.mesh.position.z).project(camera);
      cb.onPrompt({ id: nearest, x: (tmp.x * 0.5 + 0.5) * host.clientWidth, y: (-tmp.y * 0.5 + 0.5) * host.clientHeight });
    } else cb.onPrompt(null);

    // fixed framing, lightly following
    camTarget.set(player.position.x * 0.35 + lookOffset, 9, player.position.z * 0.3 + 12);
    camera.position.lerp(camTarget, 1 - Math.exp(-4 * dt));
    camera.lookAt(player.position.x * 0.35 + lookOffset * 0.6, 0.5, player.position.z * 0.3 - 1.5);

    sequence?.update(performance.now(), dt);
    renderer.render(scene, camera);
    frames++;
    if (frames >= 2 && sequenceReady) host.setAttribute("data-scene-ready", "1");
  };
  loop();

  return {
    readyEl: host,
    setPaused: (p) => { paused = p; keys.clear(); },
    setJoystick: (x, y) => { joy.x = x; joy.y = y; },
    talk,
    startSequence: () => sequence?.start(),
    resumeSequence: () => sequence?.resume(),
    flash: () => {
      muzzle.position.set(player.position.x, 1.9, player.position.z);
      muzzle.intensity = 40;
      player.children[0]!.position.y = 0.55;
    },
    scatter: () => {
      for (const n of npcs) {
        const side = n.mesh.position.x < player.position.x ? -1 : 1;
        n.flee = { x: side, z: -0.25 + Math.random() * 0.5 };
        const i = colliders.findIndex((c) => c.x === n.def.pos[0] && c.z === n.def.pos[1]);
        if (i >= 0) colliders.splice(i, 1);
      }
    },
    chase: (chaserId, weapon) => {
      const w = weapon === "stick"
        ? new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 1.6, 5), new THREE.MeshLambertMaterial({ color: "#7a5230" }))
        : new THREE.Mesh(new THREE.CircleGeometry(0.45, 12, 0, Math.PI), new THREE.MeshLambertMaterial({ color: "#d8e4ec", side: THREE.DoubleSide }));
      w.name = "weapon";
      w.position.set(0.35, 1.5, 0.1);
      for (const n of npcs) {
        if (n.def.id === chaserId) { n.mesh.add(w); n.flee = { x: 0.85, z: 0 }; chaserMesh = n.mesh; }
        else n.flee = { x: 1, z: (Math.random() - 0.5) * 0.3 };
      }
      colliders.length = 0;
      carrying = false;
      chasing = true;
    },
    carry: () => {
      const n = npcs[0];
      if (!n) return;
      player.add(n.mesh);
      n.mesh.position.set(0, 1.25, 0);
      n.mesh.rotation.set(0, 0, Math.PI / 2 - 0.15);
      n.mesh.scale.setScalar(0.6);
      colliders.length = 0;
      carrying = true;
    },
    dispose: () => {
      cancelAnimationFrame(raf);
      sequence?.dispose();
      window.removeEventListener("keydown", kd);
      window.removeEventListener("keyup", ku);
      window.removeEventListener("mousemove", mm);
      window.removeEventListener("resize", resize);
      scene.traverse((o) => {
        if (o instanceof THREE.Mesh) { o.geometry.dispose(); (o.material as THREE.Material).dispose(); }
      });
      renderer.dispose();
      renderer.domElement.remove();
    },
  };
}
