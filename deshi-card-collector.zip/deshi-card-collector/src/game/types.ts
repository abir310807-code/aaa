export interface DialogueChoice { text: string; next: string | null; setFlag?: string; /** Sound clip URL played when chosen. */ sfx?: string }
export interface DialogueNode {
  id: string;
  speaker: string;
  portrait: string; // placeholder slot label
  text: string;
  next?: string | null;
  choices?: DialogueChoice[];
  setFlag?: string;
}
export interface CharacterDef {
  id: string;
  name: string;
  color: string;
  pos: [number, number];
  facing: number;
  blipPitch: number;
  start: string; // first dialogue node
  kind?: "person" | "pole";
}
export interface CardDef { id: number; name: string; flavor: string; image: string }
export interface LevelMeta { id: number; name: string; tagline: string; card: CardDef; playable: boolean }
