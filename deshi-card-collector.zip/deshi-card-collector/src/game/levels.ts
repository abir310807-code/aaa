import type { LevelMeta } from "./types";
import antiDrugCard from "@/assets/anti_drug_card.png.asset.json";
import familyCard from "@/assets/family_card.png.asset.json";
import chandaCard from "@/assets/hoard_card.jpg.asset.json";
import electricityCard from "@/assets/electricity_card.jpg.asset.json";
import footpathCard from "@/assets/footpath_card.png.asset.json";

export const LEVELS: LevelMeta[] = [
  { id: 1, name: "The Kiosk Street", tagline: "Tutorial — walk, look, talk.", card: { id: 1, name: "Family Card", flavor: "The card that feeds a family.", image: familyCard.url }, playable: true },
  { id: 2, name: "The Air Shot", tagline: "Ishraque Bhai clears the alley.", card: { id: 2, name: "Anti-Drug Card", flavor: "Madok Birodhi Card — beyond the future.", image: antiDrugCard.url }, playable: true },
  { id: 3, name: "The 10 on 10 She", tagline: "Leader pays the old pole a visit.", card: { id: 3, name: "Electricity Card", flavor: "Bidyut Bibhag — the pole comes with you.", image: electricityCard.url }, playable: true },
  { id: 4, name: "The Hisab", tagline: "Halka Shamsu comes to collect.", card: { id: 4, name: "Chanda Card", flavor: "Sodossho obodan nibondhon — paid in lathi.", image: chandaCard.url }, playable: true },
  { id: 5, name: "The Foothpath", tagline: "Manush asks the price. The street answers.", card: { id: 5, name: "Footpath Card", flavor: "Footpath Babosayee Nibondhon — keep clear of traffic.", image: footpathCard.url }, playable: true },
];
