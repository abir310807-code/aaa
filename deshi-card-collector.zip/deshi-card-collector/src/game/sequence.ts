import type * as THREE from "three";

export interface SequenceContext {
  scene: THREE.Scene;
  player: THREE.Group;
  npcs: Map<string, THREE.Object3D>;
  onEvent: (event: string) => void;
}

export interface LevelSequence {
  /** Resolves when sequence-specific models have loaded or their fallback is ready. */
  ready?: Promise<void>;
  start: () => void;
  /** Continue after an in-sequence dialogue. */
  resume: () => void;
  update: (now: number, dt: number) => void;
  controls: (characterId: string) => boolean;
  dispose: () => void;
}

export type SequenceFactory = (context: SequenceContext) => LevelSequence;
