import { describe, it, expect } from "vitest";
import { isUnlocked } from "./storage";

describe("level unlocks", () => {
  it("level 1 is always unlocked", () => expect(isUnlocked(1, [], false)).toBe(true));
  it("level 2 locked until level 1 completed", () => {
    expect(isUnlocked(2, [], false)).toBe(false);
    expect(isUnlocked(2, [1], false)).toBe(true);
  });
  it("?all=1 unlocks level 5", () => expect(isUnlocked(5, [], true)).toBe(true));
});
