import type * as THREE from "three";
import type { CharacterDef, DialogueNode } from "../types";
import type { Collider } from "../engine";
import type { SequenceFactory } from "../sequence";
import * as l1 from "./level01";
import * as l2 from "./level02";
import * as l3 from "./level03";
import * as l4 from "./level04";
import * as l5 from "./level05";

export interface LevelDef {
  build: (s: THREE.Scene) => Collider[];
  characters: CharacterDef[];
  dialogue: Record<string, DialogueNode>;
  talkFlag: string;
  goal: string;
  /** Air shots required after talking before the level ends (0 = none). */
  shots: number;
  /** Player carries the first character off-screen after talking. */
  carry?: boolean;
  /** After talking, this character chases everyone else off-screen holding the weapon picked via flags. */
  chase?: { chaserId: string; weapons: Record<string, "stick" | "protractor"> };
  /** Flags that count as finishing the talk (defaults to [talkFlag]). */
  doneFlags?: string[];
  playerStart?: [number, number];
  /** Level-specific cinematic driven outside React. */
  sequence?: SequenceFactory;
}

export const LEVEL_DEFS: Record<number, LevelDef> = {
  1: { build: l1.buildLevel01, characters: l1.characters, dialogue: l1.dialogue, talkFlag: l1.L1_COMPLETE_FLAG, shots: 0,
    goal: "Goal: talk to Shanti about the Family Card · WASD to move · E to talk" },
  2: { build: l2.buildLevel02, characters: l2.characters, dialogue: l2.dialogue, talkFlag: l2.L2_TALK_FLAG, shots: l2.L2_SHOTS_NEEDED,
    goal: "Goal: walk up to the smokers as Ishraque Bhai · WASD to move · E to talk" },
  3: { build: l3.buildLevel03, characters: l3.characters, dialogue: l3.dialogue, talkFlag: l3.L3_TALK_FLAG, shots: 0, carry: true,
    goal: "Goal: go talk to the 10 on 10 Pole as Leader · WASD to move · E to talk" },
  4: { build: l4.buildLevel04, characters: l4.characters, dialogue: l4.dialogue, talkFlag: l4.L4_TALK_FLAG, shots: 0,
    doneFlags: [l4.L4_LATHI, l4.L4_CHADA],
    chase: { chaserId: "akkash", weapons: { [l4.L4_LATHI]: "stick", [l4.L4_CHADA]: "protractor" } },
    goal: "Goal: go settle the hisab with Dokander Akkash as Halka Shamsu · WASD to move · E to talk" },
  5: { build: l5.buildLevel05, characters: l5.characters, dialogue: l5.dialogue, talkFlag: l5.L5_TALK_FLAG, shots: 0,
    playerStart: l5.playerStart, sequence: l5.sequence,
    goal: "Goal: ask Patla Sakin the price as Manush · WASD to move · E to talk" },
};
