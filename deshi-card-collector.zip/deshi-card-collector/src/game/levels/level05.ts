import * as THREE from "three";
import type { CharacterDef, DialogueNode } from "../types";
import type { Collider } from "../engine";
import { createFootpathSequence } from "./footpathSequence";

export const L5_TALK_FLAG = "l5_question_asked";
export const playerStart: [number, number] = [-3.6, 0.4];
export const sequence = createFootpathSequence;

export const characters: CharacterDef[] = [
  { id: "patla", name: "Patla Sakin", color: "#b96d3f", pos: [0.4, -0.75], facing: 0, blipPitch: 290, start: "m1" },
  { id: "jasim", name: "Uronto Jasim", color: "#447b68", pos: [-11.5, -0.75], facing: Math.PI / 2, blipPitch: 220, start: "p2" },
  { id: "driver", name: "The Driver", color: "#463d59", pos: [13, 1.3], facing: -Math.PI / 2, blipPitch: 180, start: "p1" },
];

const M = "Manush", P = "Patla Sakin", J = "Uronto Jasim";
export const dialogue: Record<string, DialogueNode> = {
  m1: { id: "m1", speaker: M, portrait: "P-13", text: "Piece koto?", next: null, setFlag: L5_TALK_FLAG },
  p1: { id: "p1", speaker: P, portrait: "P-14", text: "Rickshaw samne tore jhulaya tan ditasi, dara.", next: "p2" },
  p2: { id: "p2", speaker: J, portrait: "P-15", text: "Tui foothoath e boschos kn?", next: "p3" },
  p3: { id: "p3", speaker: P, portrait: "P-14", text: "Wait, Boss re call ditasi, tui dekh.", next: "p4" },
  p4: { id: "p4", speaker: J, portrait: "P-15", text: "Andolon er dak diatsi, dara!", next: null },
};

const flat = (color: string) => new THREE.MeshLambertMaterial({ color, flatShading: true });
function box(w: number, h: number, d: number, color: string, x: number, y: number, z: number) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), flat(color));
  mesh.position.set(x, y, z);
  return mesh;
}

function asphaltTexture() {
  const canvas = document.createElement("canvas");
  canvas.width = canvas.height = 128;
  const ctx = canvas.getContext("2d")!;
  ctx.fillStyle = "#55575a";
  ctx.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 900; i++) {
    const shade = 65 + Math.floor(Math.random() * 35);
    ctx.fillStyle = `rgb(${shade},${shade},${shade})`;
    ctx.fillRect(Math.random() * 128, Math.random() * 128, 1.5, 1.5);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(10, 2);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

/** A busy footpath in front of a city block, with a broad road for the final car. */
export function buildLevel05(scene: THREE.Scene): Collider[] {
  scene.background = new THREE.Color("#b8d8df");
  scene.fog = new THREE.Fog("#b8d8df", 20, 42);
  scene.add(new THREE.HemisphereLight("#fff7df", "#777263", 1.45));
  const sun = new THREE.DirectionalLight("#ffe0a3", 1.35);
  sun.position.set(-5, 11, 7);
  scene.add(sun);

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(46, 38), flat("#aaa99f"));
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  const footpath = new THREE.Mesh(new THREE.PlaneGeometry(42, 3.2), flat("#c4bdac"));
  footpath.rotation.x = -Math.PI / 2;
  footpath.position.set(0, 0.015, -1.65);
  scene.add(footpath);
  for (let x = -18; x <= 18; x += 1.4) scene.add(box(0.035, 0.018, 3.1, "#aaa392", x, 0.025, -1.65));
  scene.add(box(42, 0.16, 0.25, "#d2c9b5", 0, 0.08, 0.05));

  const road = new THREE.Mesh(
    new THREE.PlaneGeometry(42, 5.6),
    new THREE.MeshLambertMaterial({ map: asphaltTexture() }),
  );
  road.rotation.x = -Math.PI / 2;
  road.position.set(0, 0.02, 2.85);
  scene.add(road);
  for (let x = -18; x <= 18; x += 3.2) scene.add(box(1.5, 0.025, 0.14, "#eee3bd", x, 0.045, 2.85));
  scene.add(box(42, 0.14, 0.25, "#c4b9a5", 0, 0.07, 5.7));

  const cols: Collider[] = [];
  const buildings: Array<[number, number, number, number, string]> = [
    [-8.2, 4.4, 5.4, 7.4, "#b76f58"],
    [-3.3, 3.8, 4.1, 5.7, "#d1a55e"],
    [1.4, 4.5, 4.7, 8.2, "#6f9791"],
    [6.4, 4.1, 4.4, 6.5, "#c38368"],
    [10.8, 3.7, 3.8, 5.2, "#8a91a8"],
  ];
  for (const [x, w, d, h, color] of buildings) {
    scene.add(box(w, h, d, color, x, h / 2, -6.1));
    cols.push({ x, z: -6.1, hw: w / 2, hd: d / 2 });
    for (let row = 0; row < Math.floor(h / 1.35); row++) {
      for (let col = 0; col < Math.max(2, Math.floor(w / 1.2)); col++) {
        const wx = x - w / 2 + 0.65 + col * 1.15;
        const window = box(0.52, 0.62, 0.05, (row + col) % 3 === 0 ? "#f3cf75" : "#42616a", wx, 1 + row * 1.25, -3.83);
        scene.add(window);
      }
    }
    scene.add(box(w + 0.15, 0.18, 0.5, "#e1d3b8", x, h - 0.5, -3.85));
  }

  // Patla's small hawker table and the goods that will spill during the crash.
  scene.add(box(2.1, 0.16, 1.05, "#76513a", -0.8, 0.82, -1.65));
  for (const x of [-1.65, 0.05]) scene.add(box(0.12, 0.82, 0.12, "#5a3c2d", x, 0.41, -1.65));
  scene.add(box(2.35, 0.12, 1.35, "#dfb84f", -0.8, 2.25, -1.65));
  for (const x of [-1.8, 0.2]) scene.add(box(0.08, 1.5, 0.08, "#675c50", x, 1.5, -1.65));
  cols.push({ x: -0.8, z: -1.65, hw: 1.1, hd: 0.55 });

  // A few curbside details make the street feel occupied before the chaos.
  for (const x of [-5.8, 5.4]) {
    scene.add(box(0.18, 3.6, 0.18, "#4b514f", x, 1.8, -0.25));
    scene.add(box(0.75, 0.18, 0.3, "#f2d98d", x + 0.25, 3.5, -0.25));
  }
  return cols;
}
