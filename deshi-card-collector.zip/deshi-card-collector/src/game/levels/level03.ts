import * as THREE from "three";
import type { CharacterDef, DialogueNode } from "../types";
import type { Collider } from "../engine";

export const L3_TALK_FLAG = "l3_take_pole";

export const characters: CharacterDef[] = [
  { id: "pole", name: "10 on 10 Pole", color: "#7a7f86", pos: [0, -1.6], facing: 0, blipPitch: 180, start: "p1", kind: "pole" },
];

export const dialogue: Record<string, DialogueNode> = {
  p1: { id: "p1", speaker: "Leader", portrait: "P-08", text: "Kemon aso?", next: "p2" },
  p2: { id: "p2", speaker: "10 on 10 Pole", portrait: "P-09", text: "Ki holo, aj etodin por amar kotha moneh porlo?", next: "p3" },
  p3: { id: "p3", speaker: "Leader", portrait: "P-08", text: "Ki korbo bolo?", next: "p4" },
  p4: { id: "p4", speaker: "10 on 10 Pole", portrait: "P-09", text: "Eto bochor lage eituku rasta aste?", next: "p5" },
  p5: { id: "p5", speaker: "Leader", portrait: "P-08", text: "Ami idea niye aschi, kono somossa nai.", next: "p6" },
  p6: {
    id: "p6", speaker: "10 on 10 Pole", portrait: "P-09", text: "Ki ar korba.\n\n",
    choices: [{ text: "success the plan", next: null, setFlag: L3_TALK_FLAG }],
  },
};

const flat = (c: string) => new THREE.MeshLambertMaterial({ color: c, flatShading: true });
function box(w: number, h: number, d: number, c: string, x: number, y: number, z: number) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), flat(c));
  m.position.set(x, y, z);
  return m;
}

/** Dusty roadside at golden hour, a lone electric pole. */
export function buildLevel03(scene: THREE.Scene): Collider[] {
  scene.background = new THREE.Color("#f0c58a");
  scene.fog = new THREE.Fog("#f0c58a", 14, 30);
  scene.add(new THREE.HemisphereLight("#ffe2b8", "#7a5a3a", 1.4));
  const sun = new THREE.DirectionalLight("#ffd29a", 1.4);
  sun.position.set(-6, 10, 4);
  scene.add(sun);

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), flat("#b8925e"));
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);
  const road = new THREE.Mesh(new THREE.PlaneGeometry(40, 3), flat("#5c5752"));
  road.rotation.x = -Math.PI / 2;
  road.position.set(0, 0.01, 1.5);
  scene.add(road);
  for (let x = -18; x < 18; x += 2.5) scene.add(box(1.2, 0.02, 0.12, "#e8e0c8", x, 0.02, 1.5));

  const cols: Collider[] = [];
  const shops: [number, number, number, number, number, string][] = [
    [-6.5, -6, 4, 3, 3.2, "#c96f4a"], [6.5, -6, 4.5, 3, 2.8, "#5f8a7a"], [-1, -7, 3, 2, 2.2, "#d9b25a"],
  ];
  for (const [x, z, w, d, h, c] of shops) {
    scene.add(box(w, h, d, c, x, h / 2, z));
    cols.push({ x, z, hw: w / 2, hd: d / 2 });
  }
  // tangled wires off to the sides
  for (const s of [-1, 1]) scene.add(box(9, 0.03, 0.03, "#222", s * 5, 4.3, -1.6));
  return cols;
}
