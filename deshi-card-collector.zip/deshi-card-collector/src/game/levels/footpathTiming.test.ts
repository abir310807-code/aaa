import { describe, expect, it } from "vitest";
import { footpathCarTimeline, footpathCarX } from "./footpathTiming";

describe("The Foothpath car timing", () => {
  it("starts the uploaded sound exactly two seconds before the car enters", () => {
    const t = footpathCarTimeline();
    expect(t.carEnter - t.soundStart).toBe(2);
  });

  it("plays the remaining five seconds while the car crosses the scene", () => {
    const t = footpathCarTimeline();
    expect(t.complete - t.carEnter).toBe(5);
  });

  it("completes at the end of the seven-second song", () => {
    const t = footpathCarTimeline();
    expect(t.complete - t.soundStart).toBe(7);
  });

  it("keeps the car moving after impact and exits beyond the whole road", () => {
    const t = footpathCarTimeline();
    const impactAge = t.carHit - t.carEnter;
    expect(footpathCarX(impactAge)).toBeCloseTo(0.4);
    expect(footpathCarX(impactAge + 1)).toBeLessThan(footpathCarX(impactAge));
    expect(footpathCarX(impactAge + 2)).toBeLessThan(footpathCarX(impactAge + 1));
    expect(footpathCarX(0)).toBe(24);
    expect(footpathCarX(5)).toBe(-24);
  });

  it("hits the hawker and puller after the car enters and before completion", () => {
    const t = footpathCarTimeline();
    expect(t.carHit).toBeGreaterThan(t.carEnter);
    expect(t.carHit).toBeLessThan(t.complete);
  });
});
