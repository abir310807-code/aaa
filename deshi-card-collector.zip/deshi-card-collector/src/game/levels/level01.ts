import * as THREE from "three";
import type { CharacterDef, DialogueNode } from "../types";
import type { Collider } from "../engine";

export const L1_COMPLETE_FLAG = "l1_paper_bought";

export const characters: CharacterDef[] = [
  { id: "shanti", name: "Shanti", color: "#d9643a", pos: [0, -1.6], facing: 0, blipPitch: 520, start: "s1" },
  { id: "tomas", name: "Boyosko Bakti", color: "#5a7d9a", pos: [-5.2, 2.5], facing: Math.PI / 2, blipPitch: 240, start: "t1" },
];

export const dialogue: Record<string, DialogueNode> = {
  s1: { id: "s1", speaker: "Shanti", portrait: "P-01", text: "Hello, ki chai?", next: "a1" },
  a1: { id: "a1", speaker: "Arjun", portrait: "P-03", text: "Apnake arki?", next: "s2" },
  s2: { id: "s2", speaker: "Shanti", portrait: "P-01", text: "Maneh?", next: "a2" },
  a2: { id: "a2", speaker: "Arjun", portrait: "P-03", text: "Yeah, maneh — family lagbe, arki?", next: "s3" },
  s3: { id: "s3", speaker: "Shanti", portrait: "P-01", text: "Family diye ki korben?", next: "a3" },
  a3: { id: "a3", speaker: "Arjun", portrait: "P-03", text: "Family pele pawa jacche — Family Card! Janen na?", next: "s4" },
  s4: { id: "s4", speaker: "Shanti", portrait: "P-01", text: "Na to.", next: "a4" },
  a4: { id: "a4", speaker: "Arjun", portrait: "P-03", text: "Sorkar dicche — family der mashe 2500 taka kore.", next: "s5" },
  s5: { id: "s5", speaker: "Shanti", portrait: "P-01", text: "Bolen ki?! Taile to ekhoni family lagbe!", next: "a5" },
  a5: { id: "a5", speaker: "Arjun", portrait: "P-03", text: "Taile cholen, amra family babostha kori.", next: "s6" },
  s6: { id: "s6", speaker: "Shanti", portrait: "P-01", text: "Cholen taile.", next: null, setFlag: L1_COMPLETE_FLAG },
  t1: { id: "t1", speaker: "Boyosko Bakti", portrait: "P-02", text: "Hm? Fifty years on this bench. Shanti's papers are the only thing that never changed.", next: "t2" },
  t2: { id: "t2", speaker: "Boyosko Bakti", portrait: "P-02", text: "Go on, buy one. She remembers every face that does.", next: null },
};

const flat = (c: string) => new THREE.MeshLambertMaterial({ color: c, flatShading: true });

function box(w: number, h: number, d: number, c: string, x: number, y: number, z: number, ry = 0) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), flat(c));
  m.position.set(x, y, z);
  m.rotation.y = ry;
  return m;
}
function cyl(r: number, h: number, c: string, x: number, y: number, z: number, seg = 6) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, h, seg), flat(c));
  m.position.set(x, y, z);
  return m;
}

/** Builds Kiosk Street. Returns static colliders (AABBs in xz). */
export function buildLevel01(scene: THREE.Scene): Collider[] {
  scene.background = new THREE.Color("#f6c9a0");
  scene.fog = new THREE.Fog("#f6c9a0", 14, 30);
  scene.add(new THREE.HemisphereLight("#ffe7c8", "#8a6a55", 1.4));
  const sun = new THREE.DirectionalLight("#ffd29a", 1.6);
  sun.position.set(-8, 10, 6);
  scene.add(sun);

  // ground: sidewalk + road strip
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), flat("#d8c3a5"));
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);
  const road = new THREE.Mesh(new THREE.PlaneGeometry(40, 3.2), flat("#6e6460"));
  road.rotation.x = -Math.PI / 2;
  road.position.set(0, 0.01, 4.8);
  scene.add(road);
  for (let i = -4; i <= 4; i++) scene.add(box(1, 0.02, 0.15, "#efe4cf", i * 3, 0.02, 4.8));

  const cols: Collider[] = [];
  // buildings along back + sides: [x, z, w, d, h, wall, roof]
  const bld: [number, number, number, number, number, string, string][] = [
    [-7, -6, 3.6, 3, 4.2, "#f1dcc0", "#b4553a"],
    [-3, -6.5, 3.4, 3, 5.4, "#e9b98d", "#6b4a3a"],
    [1, -6.2, 3.6, 3, 3.6, "#f5e6cf", "#3f6b6a"],
    [5, -6.5, 3.4, 3, 4.8, "#e6a77d", "#7a3d2f"],
    [8.8, -2, 2.6, 3.4, 3.4, "#f0d6b4", "#4f5d75"],
    [-9.2, -1.5, 2.6, 3.4, 3.8, "#ebcaa2", "#8a5a3a"],
  ];
  for (const [x, z, w, d, h, wall, roof] of bld) {
    scene.add(box(w, h, d, wall, x, h / 2, z));
    scene.add(box(w + 0.3, 0.3, d + 0.3, roof, x, h + 0.15, z));
    scene.add(box(0.8, 1.4, 0.05, "#5b3b2a", x, 0.7, z + d / 2 + 0.03)); // door
    scene.add(box(0.7, 0.6, 0.05, "#a9d3d6", x - w / 4 - 0.2, h * 0.65, z + d / 2 + 0.03));
    cols.push({ x, z, hw: w / 2, hd: d / 2 });
  }
  // the kiosk
  scene.add(box(2.2, 1.1, 1.2, "#2f6f6a", 0, 0.55, -2.8));
  scene.add(box(2.6, 0.12, 1.6, "#d9643a", 0, 2.1, -2.6));
  scene.add(cyl(0.06, 1.0, "#3a3a3a", -1.1, 1.6, -2.2, 4));
  scene.add(cyl(0.06, 1.0, "#3a3a3a", 1.1, 1.6, -2.2, 4));
  scene.add(box(1.6, 0.06, 0.5, "#f4efe4", 0, 1.13, -2.5));
  cols.push({ x: 0, z: -2.8, hw: 1.1, hd: 0.6 });

  // road props (8): bench, planter, crate get collision
  scene.add(box(1.6, 0.12, 0.5, "#8b5a3c", -5.2, 0.45, 2.5, Math.PI / 2));
  scene.add(box(0.12, 0.5, 1.6, "#8b5a3c", -5.45, 0.75, 2.5));
  cols.push({ x: -5.2, z: 2.5, hw: 0.3, hd: 0.8 });
  for (const lx of [-3, 4.5]) {
    scene.add(cyl(0.07, 3, "#2e2e2e", lx, 1.5, 2.9, 5));
    scene.add(box(0.35, 0.3, 0.35, "#fff2c4", lx, 3.1, 2.9));
  }
  scene.add(box(1, 0.6, 1, "#9a6b4b", 3.2, 0.3, -2.2, 0.3));
  scene.add(new THREE.Mesh(new THREE.IcosahedronGeometry(0.55, 0), flat("#5f8f4e")).translateX(3.2).translateY(0.9).translateZ(-2.2));
  cols.push({ x: 3.2, z: -2.2, hw: 0.5, hd: 0.5 });
  scene.add(box(0.8, 0.8, 0.8, "#b98b5a", 7, 0.4, 1.5, 0.5));
  cols.push({ x: 7, z: 1.5, hw: 0.45, hd: 0.45 });
  scene.add(cyl(0.18, 0.5, "#c8382c", -1.8, 0.25, 3.1));
  scene.add(new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.5, 5), flat("#f07a2a")).translateX(2).translateY(0.25).translateZ(3.4));
  scene.add(cyl(0.3, 0.8, "#4e5a52", 6.2, 0.4, -3.6));
  const sb = box(0.6, 0.8, 0.05, "#2b2b2b", -1.6, 0.4, -1.5, 0.4);
  sb.rotation.x = 0.2;
  scene.add(sb);
  return cols;
}
