import { describe, expect, it } from "vitest";
import { shouldPlayScream } from "./level02";

describe("Level 2 scream timing", () => {
  it("does not play after the first air shot", () => {
    expect(shouldPlayScream(1)).toBe(false);
  });

  it("plays exactly when the second air shot is completed", () => {
    expect(shouldPlayScream(2)).toBe(true);
  });

  it("does not replay on later shot counts", () => {
    expect(shouldPlayScream(3)).toBe(false);
  });
});
