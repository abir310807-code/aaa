import * as THREE from "three";
import type { CharacterDef, DialogueNode } from "../types";
import type { Collider } from "../engine";

export const L2_TALK_FLAG = "l2_talked";
export const L2_SHOTS_NEEDED = 2;
export const shouldPlayScream = (shotsFired: number) => shotsFired === L2_SHOTS_NEEDED;

export const characters: CharacterDef[] = [
  { id: "guli", name: "Guli Mokhlesh", color: "#6f8f3a", pos: [-1.1, -1.4], facing: 0.3, blipPitch: 330, start: "g1" },
  { id: "kader", name: "Shooter Kader", color: "#8a4b6b", pos: [0.2, -2.0], facing: 0, blipPitch: 420, start: "g1" },
  { id: "derby", name: "Derby Kaka", color: "#b08a3c", pos: [1.3, -1.3], facing: -0.3, blipPitch: 260, start: "g1" },
];

export const dialogue: Record<string, DialogueNode> = {
  g1: { id: "g1", speaker: "Guli Mokhlesh", portrait: "P-04", text: "Dekh dekh, Ishraque bhai asche!", next: "k1" },
  k1: { id: "k1", speaker: "Shooter Kader", portrait: "P-05", text: "Areh, are pala!", next: "d1" },
  d1: { id: "d1", speaker: "Derby Kaka", portrait: "P-06", text: "Am I looking stoned to you guys?", next: "i1" },
  i1: {
    id: "i1", speaker: "Ishraque Bhai", portrait: "P-07", text: "…",
    choices: [
      { text: "Na bhai, ekdom na — tui to sober.", next: null, setFlag: L2_TALK_FLAG },
      { text: "Chol tore, stoners aren't pretty — maneh bujhaitasi.", next: null, setFlag: L2_TALK_FLAG },
    ],
  },
};

const flat = (c: string, o = 1) => new THREE.MeshLambertMaterial({ color: c, flatShading: true, transparent: o < 1, opacity: o });
function box(w: number, h: number, d: number, c: string, x: number, y: number, z: number) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), flat(c));
  m.position.set(x, y, z);
  return m;
}

/** Night alley behind the kiosks. */
export function buildLevel02(scene: THREE.Scene): Collider[] {
  scene.background = new THREE.Color("#1d2238");
  scene.fog = new THREE.Fog("#1d2238", 12, 28);
  scene.add(new THREE.HemisphereLight("#8fa0d8", "#2a2030", 0.9));
  const lamp = new THREE.PointLight("#ffb866", 30, 14);
  lamp.position.set(0, 3.4, -0.5);
  scene.add(lamp);

  const ground = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), flat("#4a4552"));
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  const cols: Collider[] = [];
  const walls: [number, number, number, number, number, string][] = [
    [-6, -6, 5, 3, 5, "#3d3a4e"], [0, -6.5, 5, 3, 6, "#4b3f4a"], [6, -6, 5, 3, 4.5, "#38415a"],
    [-9.2, -1, 2.4, 4, 4, "#433b47"], [9.2, -1, 2.4, 4, 3.6, "#3b4552"],
  ];
  for (const [x, z, w, d, h, c] of walls) {
    scene.add(box(w, h, d, c, x, h / 2, z));
    scene.add(box(0.6, 0.5, 0.05, "#f2c46a", x + 1, h * 0.7, z + d / 2 + 0.03)); // lit window
    cols.push({ x, z, hw: w / 2, hd: d / 2 });
  }
  // lamp post
  scene.add(box(0.12, 3.4, 0.12, "#222", 0, 1.7, -0.5));
  scene.add(box(0.4, 0.2, 0.4, "#ffd38a", 0, 3.45, -0.5));
  // crates the smokers sit around, a trash drum
  scene.add(box(0.8, 0.6, 0.8, "#6b4a32", 0.1, 0.3, -0.9));
  cols.push({ x: 0.1, z: -0.9, hw: 0.4, hd: 0.4 });
  scene.add(new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.9, 7), flat("#5a6a5e")).translateX(-4).translateY(0.45).translateZ(-2.5));
  cols.push({ x: -4, z: -2.5, hw: 0.35, hd: 0.35 });
  // smoke puffs above the group
  for (let i = 0; i < 7; i++) {
    const p = new THREE.Mesh(new THREE.IcosahedronGeometry(0.18 + i * 0.04, 0), flat("#c9c6cf", 0.45));
    p.position.set(Math.sin(i * 1.7) * 0.8, 1.8 + i * 0.28, -1.5 + Math.cos(i) * 0.4);
    p.name = "smoke";
    scene.add(p);
  }
  return cols;
}
