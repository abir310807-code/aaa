export const FOOTPATH_CAR_SOUND_LEAD = 2;
export const FOOTPATH_CAR_VISIBLE_FOR = 5;
const CAR_START_X = 24;
const CAR_EXIT_X = -24;
const CAR_HIT_X = 0.4;
export const FOOTPATH_CAR_HIT_AFTER_ENTRY =
  ((CAR_START_X - CAR_HIT_X) / (CAR_START_X - CAR_EXIT_X)) * FOOTPATH_CAR_VISIBLE_FOR;

/** A constant-speed drive across the entire road, including after impact. */
export function footpathCarX(secondsAfterEntry: number) {
  const progress = Math.max(0, Math.min(secondsAfterEntry / FOOTPATH_CAR_VISIBLE_FOR, 1));
  return CAR_START_X + (CAR_EXIT_X - CAR_START_X) * progress;
}

/** Wall-clock timing keeps the uploaded sound and the visible car in sync. */
export function footpathCarTimeline() {
  const soundStart = 0;
  const carEnter = soundStart + FOOTPATH_CAR_SOUND_LEAD;
  const carHit = carEnter + FOOTPATH_CAR_HIT_AFTER_ENTRY;
  const complete = carEnter + FOOTPATH_CAR_VISIBLE_FOR;
  return { soundStart, carEnter, carHit, complete };
}
