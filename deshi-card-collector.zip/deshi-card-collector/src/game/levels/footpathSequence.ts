import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import type { LevelSequence, SequenceContext } from "../sequence";
import { footpathCarTimeline, footpathCarX } from "./footpathTiming";
import sedanModel from "@/assets/models/footpath-sedan.glb.asset.json";

const flat = (color: string) => new THREE.MeshLambertMaterial({ color, flatShading: true });
function box(w: number, h: number, d: number, color: string, x: number, y: number, z: number) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), flat(color));
  mesh.position.set(x, y, z);
  return mesh;
}

function makeFallbackCar() {
  const car = new THREE.Group();
  car.add(box(3.3, 0.65, 1.55, "#a33b35", 0, 0.65, 0));
  car.add(box(1.65, 0.65, 1.35, "#d4b04d", 0.15, 1.25, 0));
  car.add(box(0.85, 0.45, 1.38, "#537582", -0.45, 1.27, 0));
  for (const x of [-1.05, 1.05]) {
    for (const z of [-0.78, 0.78]) {
      const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 0.18, 12), flat("#252729"));
      wheel.rotation.x = Math.PI / 2;
      wheel.position.set(x, 0.4, z);
      car.add(wheel);
    }
  }
  return car;
}

/** A purpose-built cycle rickshaw: no matching CC0 rickshaw model was available. */
function makeRickshaw() {
  const rickshaw = new THREE.Group();
  rickshaw.add(box(1.65, 0.18, 1.25, "#70452d", -0.55, 0.75, 0));
  rickshaw.add(box(0.25, 0.8, 1.15, "#b34f3f", -1.25, 1.15, 0));
  rickshaw.add(box(1.85, 0.16, 1.5, "#e1b942", -0.55, 2.05, 0));
  for (const z of [-0.62, 0.62]) {
    rickshaw.add(box(0.08, 1.3, 0.08, "#485858", -1.25, 1.4, z));
    rickshaw.add(box(0.08, 1.3, 0.08, "#485858", 0.15, 1.4, z));
  }
  for (const [x, z, radius] of [[-0.8, -0.78, 0.62], [-0.8, 0.78, 0.62], [1.05, 0, 0.48]] as const) {
    const wheel = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.055, 6, 18), flat("#283334"));
    wheel.position.set(x, radius, z);
    if (z !== 0) wheel.rotation.y = 0;
    rickshaw.add(wheel);
  }
  rickshaw.add(box(2.25, 0.07, 0.07, "#566667", 0.45, 0.85, -0.35));
  rickshaw.add(box(2.25, 0.07, 0.07, "#566667", 0.45, 0.85, 0.35));
  rickshaw.add(box(0.08, 0.08, 0.85, "#566667", 1.5, 1.1, 0));
  return rickshaw;
}

function normalizeCar(model: THREE.Object3D) {
  let bounds = new THREE.Box3().setFromObject(model);
  let size = bounds.getSize(new THREE.Vector3());
  if (size.z > size.x) model.rotation.y = -Math.PI / 2;
  bounds = new THREE.Box3().setFromObject(model);
  size = bounds.getSize(new THREE.Vector3());
  model.scale.setScalar(3.5 / Math.max(size.x, size.z));
  bounds = new THREE.Box3().setFromObject(model);
  const center = bounds.getCenter(new THREE.Vector3());
  model.position.x -= center.x;
  model.position.z -= center.z;
  model.position.y -= bounds.min.y;
  model.traverse((object) => {
    if (object instanceof THREE.Mesh) object.castShadow = true;
  });
}

export function createFootpathSequence({ scene, player, npcs, onEvent }: SequenceContext): LevelSequence {
  const patla = npcs.get("patla")!;
  const jasim = npcs.get("jasim")!;
  const driver = npcs.get("driver")!;
  const rickshaw = makeRickshaw();
  rickshaw.visible = false;
  scene.add(rickshaw);
  jasim.visible = false;

  const car = new THREE.Group();
  const fallback = makeFallbackCar();
  const modelSlot = new THREE.Group();
  car.add(fallback, modelSlot);
  car.visible = false;
  scene.add(car);
  car.add(driver);
  driver.position.set(0.15, 0.72, 0);
  driver.scale.setScalar(0.62);
  driver.rotation.set(0, -Math.PI / 2, 0);
  driver.visible = false;

  let disposed = false;
  const ready = new Promise<void>((resolve) => {
    new GLTFLoader().load(sedanModel.url, (gltf) => {
      if (!disposed) {
        normalizeCar(gltf.scene);
        modelSlot.add(gltf.scene);
        fallback.visible = false;
      }
      resolve();
    }, undefined, () => resolve());
  });

  const goods = Array.from({ length: 14 }, (_, i) => {
    const mesh = box(0.25, 0.22, 0.25, ["#d94a3a", "#efbd3d", "#5589c6", "#6c9b4d"][i % 4]!, 0, 0, 0);
    mesh.visible = false;
    scene.add(mesh);
    return {
      mesh,
      start: new THREE.Vector3(-1.55 + (i % 7) * 0.25, 0.98 + Math.floor(i / 7) * 0.23, -1.65),
      velocity: new THREE.Vector3(-2.4 + (i % 7) * 0.8, 2.2 + (i % 4) * 0.35, -0.8 + Math.floor(i / 4) * 0.65),
    };
  });

  type Stage = "idle" | "rickshaw" | "waiting" | "car" | "done";
  let stage: Stage = "idle";
  let startedAt = 0;
  let carStartedAt = 0;
  let crashed = false;
  let hit = false;
  const manushFrom = new THREE.Vector3();
  const manushAway = new THREE.Vector3(-2.8, 0, 2.5);
  const patlaHit = new THREE.Vector3();
  const jasimHit = new THREE.Vector3();
  const timing = footpathCarTimeline();

  const start = () => {
    if (stage !== "idle") return;
    stage = "rickshaw";
    startedAt = performance.now();
    manushFrom.copy(player.position);
    rickshaw.visible = true;
    jasim.visible = true;
    crashed = false;
    hit = false;
    onEvent("sequence-start");
  };

  const resume = () => {
    if (stage !== "waiting") return;
    stage = "car";
    carStartedAt = performance.now();
    onEvent("car-sound");
  };

  const update = (now: number) => {
    if (stage === "rickshaw") {
      const elapsed = (now - startedAt) / 1000;
      const approach = Math.min(elapsed / 1.35, 1);
      const rx = THREE.MathUtils.lerp(-13, -0.7, approach);
      rickshaw.position.set(rx, 0, -0.72);
      jasim.position.set(rx + 1.55, approach < 1 ? Math.abs(Math.sin(elapsed * 18)) * 0.12 : 0, -0.72);
      jasim.rotation.y = Math.PI / 2;

      if (elapsed >= 1.35 && !crashed) {
        crashed = true;
        rickshaw.rotation.z = 0.16;
        patla.position.set(0.15, 0, -0.7);
        patla.rotation.y = -Math.PI / 2;
        goods.forEach(({ mesh, start }) => { mesh.visible = true; mesh.position.copy(start); });
        onEvent("rickshaw-crash");
      }
      if (crashed) {
        const age = Math.min(elapsed - 1.35, 1.25);
        for (const { mesh, start, velocity } of goods) {
          mesh.position.set(
            start.x + velocity.x * age,
            Math.max(0.13, start.y + velocity.y * age - 4.9 * age * age),
            start.z + velocity.z * age,
          );
          mesh.rotation.set(age * velocity.z * 3, age * velocity.x * 2, age * 2);
        }
        const retreat = THREE.MathUtils.smoothstep(Math.min((elapsed - 1.35) / 0.85, 1), 0, 1);
        player.position.lerpVectors(manushFrom, manushAway, retreat);
        player.rotation.y = Math.atan2(manushAway.x - manushFrom.x, manushAway.z - manushFrom.z);
      }
      if (elapsed >= 2.25) {
        stage = "waiting";
        jasim.rotation.y = -Math.PI / 2;
        onEvent("crash-dialogue");
      }
    }

    if (stage === "car") {
      const elapsed = (now - carStartedAt) / 1000;
      car.visible = elapsed >= timing.carEnter;
      driver.visible = car.visible;
      if (car.visible) {
        car.position.set(footpathCarX(elapsed - timing.carEnter), 0, -0.65);
      }
      if (elapsed >= timing.carHit && !hit) {
        hit = true;
        patlaHit.copy(patla.position);
        jasimHit.copy(jasim.position);
        onEvent("car-hit");
      }
      if (hit) {
        const age = Math.max(0, elapsed - timing.carHit);
        patla.position.set(patlaHit.x - age * 1.6, age * 4 + age * age * 0.35, patlaHit.z + age * 0.35);
        jasim.position.set(jasimHit.x + age * 1.5, age * 4.6 + age * age * 0.4, jasimHit.z - age * 0.25);
        patla.rotation.set(age * 4, age * 2, age * 5);
        jasim.rotation.set(age * 5, age * 3, -age * 4);
      }
      if (elapsed >= timing.complete) {
        stage = "done";
        car.visible = false;
        driver.visible = false;
        onEvent("complete");
      }
    }
  };

  return {
    ready,
    start,
    resume,
    update,
    controls: (id) => id === "driver" || (stage !== "idle" && (id === "patla" || id === "jasim")),
    dispose: () => {
      disposed = true;
      scene.add(driver);
      scene.remove(car, rickshaw);
      goods.forEach(({ mesh }) => scene.remove(mesh));
    },
  };
}
