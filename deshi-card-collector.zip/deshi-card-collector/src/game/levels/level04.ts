import * as THREE from "three";
import type { CharacterDef, DialogueNode } from "../types";
import type { Collider } from "../engine";
import salam from "@/assets/salam.mp3.asset.json";

export const L4_TALK_FLAG = "l4_weapon_picked";
export const L4_LATHI = "l4_lathi";
export const L4_CHADA = "l4_chada";

export const characters: CharacterDef[] = [
  { id: "akkash", name: "Dokander Akkash", color: "#c7a24a", pos: [0, -2.2], facing: 0, blipPitch: 300, start: "s0" },
  { id: "jewel", name: "Pistol Jewel", color: "#3b3b3b", pos: [2.2, -0.2], facing: -0.6, blipPitch: 220, start: "s0" },
];

const S = "Dokander Akkash", H = "Halka Shamsu", J = "Pistol Jewel";
export const dialogue: Record<string, DialogueNode> = {
  s0: { id: "s0", speaker: H, portrait: "P-10", text: "…", choices: [{ text: "Give salam", next: "a1", sfx: salam.url }] },
  a1: { id: "a1", speaker: S, portrait: "P-11", text: "Walaikum salam bhatija, ki lagbo?", next: "a2" },
  a2: { id: "a2", speaker: H, portrait: "P-10", text: "Kaka, masher hisabh ta je clear na.", next: "a3" },
  a3: { id: "a3", speaker: S, portrait: "P-11", text: "Ki hisabh mitan lagbo go?", next: "a4" },
  a4: { id: "a4", speaker: H, portrait: "P-10", text: "Pistol Jewel, bujha to here.", next: "a5" },
  a5: { id: "a5", speaker: J, portrait: "P-12", text: "Oi je jeita hisebe ase, bhai er kotha moneh nai?", next: "a6" },
  a6: { id: "a6", speaker: S, portrait: "P-11", text: "tr bhai ki amr bou er dewa gali je ore moneh rakhum.", next: "a7" },
  a7: { id: "a7", speaker: J, portrait: "P-12", text: "Areh areh, ekdom khaya dimu koilam!", next: "a8" },
  a8: { id: "a8", speaker: S, portrait: "P-11", text: "Kn, amre ajke beshi sundor lagtase?", next: "a9" },
  a9: { id: "a9", speaker: J, portrait: "P-12", text: "Bhai kintu rokto jhoraya dibo!", next: "a10" },
  a10: { id: "a10", speaker: S, portrait: "P-11", text: "Kn, tr bhai er piles naki?", next: "a11" },
  a11: { id: "a11", speaker: J, portrait: "P-12", text: "Amr pran priyo bhai er loge eto boro moja!", next: "a12" },
  a12: {
    id: "a12", speaker: S, portrait: "P-11", text: "Daara…",
    choices: [
      { text: "A. Lathi (stick)", next: null, setFlag: L4_LATHI },
      { text: "B. Chada (protractor)", next: null, setFlag: L4_CHADA },
    ],
  },
};

const flat = (c: string) => new THREE.MeshLambertMaterial({ color: c, flatShading: true });
function box(w: number, h: number, d: number, c: string, x: number, y: number, z: number) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), flat(c));
  m.position.set(x, y, z);
  return m;
}

/** Corner grocery with a counter and shelves. */
export function buildLevel04(scene: THREE.Scene): Collider[] {
  scene.background = new THREE.Color("#cfe3e0");
  scene.fog = new THREE.Fog("#cfe3e0", 14, 30);
  scene.add(new THREE.HemisphereLight("#ffffff", "#8a7a60", 1.3));
  const sun = new THREE.DirectionalLight("#fff2d8", 1.2);
  sun.position.set(4, 10, 6);
  scene.add(sun);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), flat("#a9a59a"));
  ground.rotation.x = -Math.PI / 2;
  scene.add(ground);

  const cols: Collider[] = [];

  // road in front of the store: shop-side pavement, asphalt, kerbs, far pavement, dashed centre line
  const groundPlane = (w: number, d: number, c: string, z: number, y: number) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), flat(c));
    m.rotation.x = -Math.PI / 2;
    m.position.set(0, y, z);
    scene.add(m);
  };
  groundPlane(40, 2.0, "#c2bcae", 0, 0.005); // pavement in front of the counter
  groundPlane(40, 2.3, "#4f4a48", 2.15, 0.01); // asphalt
  groundPlane(40, 1.9, "#c2bcae", 4.25, 0.005); // pavement across the road
  for (const z of [1.0, 3.3]) scene.add(box(40, 0.12, 0.25, "#bdb6a8", 0, 0.06, z));
  for (let k = -6; k <= 6; k++) scene.add(box(1.1, 0.02, 0.16, "#f4ecd2", k * 2.6, 0.03, 2.15));

  // shop shell + awning
  scene.add(box(7, 3.2, 0.3, "#e08a4a", 0, 1.6, -4.2));
  scene.add(box(7.4, 0.15, 1.6, "#2f7a5a", 0, 3.1, -3.4));
  // shelves with goods
  for (let i = 0; i < 3; i++) {
    scene.add(box(6, 0.08, 0.6, "#6b4a32", 0, 0.9 + i * 0.7, -3.8));
    for (let k = 0; k < 8; k++) scene.add(box(0.35, 0.4, 0.3, ["#d94a3a", "#f2c23a", "#3a8ad9", "#5ab04a"][(k + i) % 4]!, -2.6 + k * 0.75, 1.15 + i * 0.7, -3.8));
  }
  // counter
  scene.add(box(4, 1, 0.8, "#8a5a3a", 0, 0.5, -1.3));
  cols.push({ x: 0, z: -3.9, hw: 3.5, hd: 0.5 }, { x: 0, z: -1.3, hw: 2, hd: 0.4 });
  // sacks of rice outside
  for (const x of [-3.4, -2.8, 3.2]) {
    scene.add(new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.35, 0.6, 7), flat("#e8dcb8")).translateX(x).translateY(0.3).translateZ(-1.6));
    cols.push({ x, z: -1.6, hw: 0.3, hd: 0.3 });
  }
  return cols;
}
