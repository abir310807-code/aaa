// All persistent state lives in localStorage under cc_ keys.
export const LEVEL_COUNT = 5;

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write(key: string, v: unknown) {
  localStorage.setItem(key, JSON.stringify(v));
}

export const getVault = () => read<number[]>("cc_vault", []);
export const getCompleted = () => read<number[]>("cc_completed", []);

export function completeLevel(id: number) {
  const done = getCompleted();
  if (!done.includes(id)) write("cc_completed", [...done, id]);
}
export function collectCard(id: number) {
  const v = getVault();
  if (!v.includes(id)) write("cc_vault", [...v, id]);
}

/** Level N+1 unlocks when N is completed; level 1 always open; ?all=1 opens everything. */
export function isUnlocked(id: number, completed: number[], all: boolean) {
  return all || id === 1 || completed.includes(id - 1);
}

export interface AudioSettings { master: number; sfx: number; music: number; muted: boolean }
export const defaultAudio: AudioSettings = { master: 0.8, sfx: 0.8, music: 0.5, muted: false };
export const getAudioSettings = () => ({ ...defaultAudio, ...read<Partial<AudioSettings>>("cc_audio", {}) });
export const saveAudioSettings = (s: AudioSettings) => write("cc_audio", s);
