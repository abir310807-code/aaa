# Model credits

- `footpath-sedan.glb`: Sedan from Kenney's Car Kit, CC0 1.0. Model mirror: https://models.codelove.in/models/car-kit-sedan/ — collection and license: https://models.codelove.in/models/collection/car-kit/
