import { useEffect, useRef, useState } from "react";
import { createRuntime, type Runtime } from "@/game/engine";
import { LEVEL_DEFS } from "@/game/levels/registry";
import { LEVELS } from "@/game/levels";
import { startAmbient, stopAmbient, sound } from "@/game/audio";
import { collectCard, completeLevel, getAudioSettings } from "@/game/storage";
import level3Bgm from "@/assets/level03_bgm.mp3.asset.json";
import level1Bgm from "@/assets/level01_bgm.mp3.asset.json";
import { DialogueBox } from "./DialogueBox";
import { CardAward } from "./CardAward";
import footpathCar from "@/assets/footpath_car_song.mp3.asset.json";
import smokerScream from "@/assets/level02_scream.mp3.asset.json";
import ahoBatija from "@/assets/aho_batija.mp3.asset.json";
import { shouldPlayScream } from "@/game/levels/level02";
import { Button } from "@/components/ui/button";

type Phase = "walk" | "talk" | "shoot" | "flee" | "cinematic" | "award";

export function LevelView({ levelId, onExit }: { levelId: number; onExit: (completed: boolean) => void }) {
  const host = useRef<HTMLDivElement>(null);
  const rt = useRef<Runtime | null>(null);
  const flags = useRef(new Set<string>());
  const [prompt, setPrompt] = useState<{ id: string; x: number; y: number } | null>(null);
  const [talking, setTalking] = useState<string | null>(null);
  const [talkStart, setTalkStart] = useState<string | null>(null);
  const [phase, setPhase] = useState<Phase>("walk");
  const [shots, setShots] = useState(0);
  const [sequenceStatus, setSequenceStatus] = useState("Watch the footpath…");
  const carAudio = useRef<HTMLAudioElement | null>(null);
  const screamAudio = useRef<HTMLAudioElement | null>(null);
  const level = LEVELS.find((l) => l.id === levelId)!;
  const def = LEVEL_DEFS[levelId]!;
  const { characters, dialogue } = def;

  const finish = () => { completeLevel(level.id); sound.sting(); setPhase("award"); };
  const handleSequenceEvent = (event: string) => {
    if (event === "sequence-start") setSequenceStatus("Uronto Jasim is coming too fast…");
    if (event === "rickshaw-crash") { sound.crash(); setSequenceStatus("The hawker's goods are everywhere!"); }
    if (event === "crash-dialogue") {
      setTalkStart("p1");
      setTalking("patla");
      setPhase("talk");
    }
    if (event === "car-sound") {
      setSequenceStatus("Wait… what is that sound?");
      const audio = new Audio(footpathCar.url);
      carAudio.current = audio;
      void audio.play().catch(() => {});
    }
    if (event === "car-hit") { sound.launch(); setSequenceStatus("There they go!"); }
    if (event === "complete") finish();
  };

  useEffect(() => {
    const r = createRuntime(host.current!, def.build, characters, {
      onPrompt: (p) => setPrompt((prev) => (!p && !prev ? prev : p)),
      onTalk: (id) => { setTalkStart(null); setTalking(id); setPhase("talk"); },
      onSequenceEvent: handleSequenceEvent,
    }, { playerStart: def.playerStart, sequence: def.sequence });
    rt.current = r;
    startAmbient();
    if (levelId === 2) sound.wind();
    let bgm: HTMLAudioElement | null = null;
    if (levelId === 3 || levelId === 1) {
      const s = getAudioSettings();
      bgm = new Audio(levelId === 1 ? level1Bgm.url : level3Bgm.url);
      bgm.loop = true;
      const base = levelId === 1 ? 0.04 : 0.2;
      bgm.volume = s.muted ? 0 : Math.min(1, base * s.master * (s.music / 0.5));
      void bgm.play().catch(() => {});
    }
    return () => { r.dispose(); stopAmbient(); bgm?.pause(); carAudio.current?.pause(); screamAudio.current?.pause(); };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { rt.current?.setPaused(phase !== "walk"); }, [phase]);

  const closeDialogue = () => {
    const completedStart = talkStart;
    setTalking(null);
    setTalkStart(null);
    if (def.sequence) {
      if (completedStart === "p1") {
        rt.current?.resumeSequence();
        setSequenceStatus("The argument is getting louder…");
      } else rt.current?.startSequence();
      setPhase("cinematic");
      return;
    }
    const done = (def.doneFlags ?? [def.talkFlag]).find((f) => flags.current.has(f));
    if (!done) return setPhase("walk");
    if (def.chase) {
      rt.current?.chase(def.chase.chaserId, def.chase.weapons[done] ?? "stick");
      if (levelId === 4) {
        const audio = new Audio(ahoBatija.url);
        screamAudio.current = audio;
        void audio.play().catch(() => {});
      }
      setPhase("flee");
      setTimeout(finish, 3000);
    } else if (def.carry) {
      rt.current?.carry();
      setPhase("flee");
      setTimeout(finish, 3000);
    } else if (def.shots > 0) setPhase("shoot"); else finish();
  };

  const shoot = () => {
    if (phase !== "shoot") return;
    sound.gunshot();
    rt.current?.flash();
    const n = shots + 1;
    setShots(n);
    if (n >= def.shots) {
      rt.current?.scatter();
      if (level.id === 2 && shouldPlayScream(n)) {
        const audio = new Audio(smokerScream.url);
        screamAudio.current = audio;
        void audio.play().catch(() => {});
      }
      setPhase("flee");
      setTimeout(finish, 2200);
    }
  };

  useEffect(() => {
    if (phase !== "shoot") return;
    const kd = (e: KeyboardEvent) => { if (e.code === "KeyF" && !e.repeat) shoot(); };
    window.addEventListener("keydown", kd);
    return () => window.removeEventListener("keydown", kd);
  });

  const ch = characters.find((c) => c.id === talking);
  return (
    <div className="fixed inset-0 bg-background">
      <div ref={host} className="absolute inset-0" />
      <div className="pointer-events-none absolute left-4 top-4 z-10">
        <div className="panel px-4 py-2">
          <div className="font-display text-lg">{level.name}</div>
          <div className="text-xs text-muted-foreground">
            {phase === "shoot" ? `Fire in the air to scare them off · ${shots}/${def.shots}` : phase === "cinematic" ? sequenceStatus : phase === "flee" ? (def.carry ? "Taking the pole away…" : def.chase ? "Run! Akkash is coming!" : "They're running!") : def.goal}
          </div>
        </div>
      </div>
      <button className="btn-ghost absolute right-4 top-4 z-10" onClick={() => onExit(false)}>Leave</button>
      {phase === "walk" && prompt && (
        <button className="talk-prompt z-10" style={{ left: prompt.x, top: prompt.y }} onClick={() => rt.current?.talk()}>
          E · Talk to {characters.find((c) => c.id === prompt.id)?.name}
        </button>
      )}
      {phase === "shoot" && (
        <div className="absolute inset-x-0 bottom-10 z-10 flex justify-center">
          <Button variant="game" size="game" className="btn-game px-8" onClick={shoot}>Shoot in the air ({def.shots - shots} left)</Button>
        </div>
      )}
      {phase === "walk" && <DPad onMove={(x, y) => rt.current?.setJoystick(x, y)} />}
      {phase === "walk" && (
        <Button variant="game" size="game" className="touch-action-btn z-10" disabled={!prompt} aria-label="Talk"
          onClick={() => rt.current?.talk()}>Talk</Button>
      )}
      {phase === "talk" && ch && (
        <DialogueBox nodes={dialogue} start={talkStart ?? ch.start} pitch={ch.blipPitch}
          onFlag={(f) => flags.current.add(f)} onClose={closeDialogue} />
      )}
      {phase === "award" && (
        <CardAward card={level.card} onCollect={() => { collectCard(level.card.id); onExit(true); }} />
      )}
    </div>
  );
}

function DPad({ onMove }: { onMove: (x: number, y: number) => void }) {
  const dirs: [string, string, number, number][] = [
    ["Up", "▲", 0, -1], ["Left", "◀", -1, 0], ["Right", "▶", 1, 0], ["Down", "▼", 0, 1],
  ];
  const stop = () => onMove(0, 0);
  return (
    <div className="dpad z-10">
      {dirs.map(([name, glyph, x, y]) => (
        <Button variant="game" size="game" key={name} aria-label={`Move ${name.toLowerCase()}`} className={`dpad-btn dpad-${name.toLowerCase()}`}
          onPointerDown={(e) => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); onMove(x, y); }}
          onPointerUp={stop} onPointerCancel={stop} onLostPointerCapture={stop} onContextMenu={(e) => e.preventDefault()}>{glyph}</Button>
      ))}
    </div>
  );
}

export function Joystick({ onMove }: { onMove: (x: number, y: number) => void }) {
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const base = useRef<HTMLDivElement>(null);
  const move = (e: React.PointerEvent) => {
    if (e.buttons === 0 && e.pointerType === "mouse") return;
    const b = base.current!.getBoundingClientRect();
    let x = (e.clientX - b.left - b.width / 2) / (b.width / 2);
    let y = (e.clientY - b.top - b.height / 2) / (b.height / 2);
    const l = Math.hypot(x, y);
    if (l > 1) { x /= l; y /= l; }
    setKnob({ x, y });
    onMove(x, y);
  };
  const end = () => { setKnob({ x: 0, y: 0 }); onMove(0, 0); };
  return (
    <div ref={base} className="joystick z-10" onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); move(e); }}
      onPointerMove={move} onPointerUp={end} onPointerCancel={end}>
      <div className="joystick-knob" style={{ transform: `translate(${knob.x * 32}px, ${knob.y * 32}px)` }} />
    </div>
  );
}
