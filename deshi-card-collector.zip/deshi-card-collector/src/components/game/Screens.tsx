import { useState } from "react";
import { LEVELS } from "@/game/levels";
import { getAudioSettings, saveAudioSettings, isUnlocked, type AudioSettings } from "@/game/storage";
import { applySettings, sound } from "@/game/audio";
import { CardView } from "./CardAward";
import type { CardDef } from "@/game/types";

const btn = (label: string, on: () => void) => (
  <button className="btn-game" onMouseEnter={() => sound.hover()} onClick={() => { sound.click(); on(); }}>{label}</button>
);

export function Boot({ go }: { go: (s: "select" | "vault" | "options" | "credits") => void }) {
  return (
    <div className="screen items-center justify-center gap-8">
      <div className="text-center">
        <p className="eyebrow">PLAY THE GAME, IF YOU CAN</p>
        <h1 className="title-logo">Deshi Card Collector</h1>
      </div>
      <div className="flex w-64 flex-col gap-3">
        {btn("Play", () => go("select"))}
        {btn("Treasure Box", () => go("vault"))}
        {btn("Options", () => go("options"))}
        {btn("Credits", () => go("credits"))}
      </div>
    </div>
  );
}

function Back({ onBack, title }: { onBack: () => void; title: string }) {
  return (
    <div className="mb-6 flex items-center justify-between">
      <h2 className="font-display text-4xl">{title}</h2>
      <button className="btn-ghost" onClick={() => { sound.click(); onBack(); }}>← Back</button>
    </div>
  );
}

export function LevelSelect({ completed, all, onPlay, onBack }: { completed: number[]; all: boolean; onPlay: (id: number) => void; onBack: () => void }) {
  return (
    <div className="screen mx-auto max-w-5xl">
      <Back onBack={onBack} title="Choose a level" />
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
        {LEVELS.map((l) => {
          const open = isUnlocked(l.id, completed, all);
          const done = completed.includes(l.id);
          const playable = open && l.playable;
          return (
            <button key={l.id} disabled={!playable} className="level-tile" data-state={done ? "done" : open ? "open" : "locked"}
              onMouseEnter={() => playable && sound.hover()} onClick={() => { sound.click(); onPlay(l.id); }}>
              <div className="tile-thumb">{done ? <img src={l.card.image} alt="" className="h-full object-contain" /> : <span>0{l.id}</span>}</div>
              <div className="p-3 text-left">
                <div className="font-display text-xl">{l.name}</div>
                <div className="text-sm text-muted-foreground">
                  {!open ? `Locked — complete Level ${l.id - 1}` : !l.playable ? "Not built yet" : done ? `Completed · ${l.card.name}` : l.tagline}
                </div>
              </div>
              {done && <span className="stamp">Done</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function Vault({ vault, onBack }: { vault: number[]; onBack: () => void }) {
  const [zoom, setZoom] = useState<CardDef | null>(null);
  return (
    <div className="screen mx-auto max-w-3xl">
      <Back onBack={onBack} title="Vault" />
      <div className="grid grid-cols-3 gap-4">
        {LEVELS.map(({ card }) => vault.includes(card.id) ? (
          <button key={card.id} className="vault-slot" onClick={() => { sound.click(); setZoom(card); }}>
            <img src={card.image} alt={card.name} className="w-full rounded-md" />
            <span className="mt-1 block text-sm">{card.name}</span>
          </button>
        ) : (
          <div key={card.id} className="vault-slot"><div className="silhouette">???</div><span className="mt-1 block text-sm text-muted-foreground">???</span></div>
        ))}
      </div>
      {zoom && (
        <div className="fixed inset-0 z-40 flex flex-col items-center justify-center gap-4 bg-overlay-strong" onClick={() => setZoom(null)}>
          <CardView card={zoom} />
          <p className="font-display text-2xl">{zoom.name}</p>
          <p className="italic text-muted-foreground">{zoom.flavor}</p>
        </div>
      )}
    </div>
  );
}

export function Options({ onBack }: { onBack: () => void }) {
  const [s, setS] = useState<AudioSettings>(() => getAudioSettings());
  const set = (p: Partial<AudioSettings>) => { const n = { ...s, ...p }; setS(n); saveAudioSettings(n); applySettings(n); };
  const slider = (k: "master" | "sfx" | "music", label: string) => (
    <label className="flex items-center justify-between gap-4">
      <span>{label}</span>
      <input type="range" min={0} max={1} step={0.05} value={s[k]} onChange={(e) => set({ [k]: Number(e.target.value) })} onMouseUp={() => sound.click()} className="w-48 accent-primary" />
    </label>
  );
  return (
    <div className="screen mx-auto max-w-md">
      <Back onBack={onBack} title="Options" />
      <div className="panel flex flex-col gap-4 p-5">
        {slider("master", "Master")}{slider("sfx", "SFX")}{slider("music", "Music")}
        <label className="flex items-center justify-between"><span>Mute all</span>
          <input type="checkbox" checked={s.muted} onChange={(e) => set({ muted: e.target.checked })} className="h-5 w-5 accent-primary" /></label>
      </div>
    </div>
  );
}

export function Credits({ onBack }: { onBack: () => void }) {
  return (
    <div className="screen mx-auto max-w-md">
      <Back onBack={onBack} title="Credits" />
      <div className="panel p-5 leading-relaxed">Desing- Ekjon Bengali<br />Direction- Ek Sudorson Lok&nbsp;<br />Direction- Ek Sudorson Lok&nbsp;<br />Built with three.js. All sounds synthesized live.<br /><br />Card art — coming soon&nbsp;<br /><br />Onuprerona - Developer er Bhobissot&nbsp;</div>
    </div>
  );
}
