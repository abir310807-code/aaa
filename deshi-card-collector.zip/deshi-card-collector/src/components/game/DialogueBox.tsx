import { useEffect, useRef, useState } from "react";
import type { DialogueNode } from "@/game/types";
import { sound } from "@/game/audio";
import { Button } from "@/components/ui/button";

interface Props {
  nodes: Record<string, DialogueNode>;
  start: string;
  pitch: number;
  onFlag: (f: string) => void;
  onClose: () => void;
}

export function DialogueBox({ nodes, start, pitch, onFlag, onClose }: Props) {
  const [id, setId] = useState(start);
  const [shown, setShown] = useState(0);
  const node = nodes[id]!;
  const done = shown >= node.text.length;
  const holdRef = useRef(false);

  useEffect(() => {
    setShown(0);
    if (node.setFlag) onFlag(node.setFlag);
  }, [id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (done) return;
    const h = setTimeout(() => {
      setShown((s) => Math.min(node.text.length, s + (holdRef.current ? 4 : 1)));
      if (shown % 2 === 0) sound.blip(pitch + (shown % 5) * 8);
    }, 28);
    return () => clearTimeout(h);
  }, [shown, done, node.text, pitch]);

  const advance = () => {
    if (!done) { setShown(node.text.length); return; }
    if (node.choices?.length) return;
    sound.click();
    if (node.next) setId(node.next); else onClose();
  };
  const choose = (i: number) => {
    const c = node.choices![i]!;
    if (c.sfx) new Audio(c.sfx).play().catch(() => {}); else sound.click();
    if (c.setFlag) onFlag(c.setFlag);
    if (c.next) setId(c.next); else onClose();
  };

  useEffect(() => {
    const kd = (e: KeyboardEvent) => {
      if (e.code === "Escape") onClose();
      else if (e.code === "Space" || e.code === "Enter" || e.code === "KeyE") {
        if (e.repeat) holdRef.current = true; else advance();
      } else if (done && node.choices && /^Digit[1-3]$/.test(e.code)) {
        const i = Number(e.code.slice(5)) - 1;
        if (node.choices[i]) choose(i);
      }
    };
    const ku = () => { holdRef.current = false; };
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    return () => { window.removeEventListener("keydown", kd); window.removeEventListener("keyup", ku); };
  });

  return (
    <div className="absolute inset-0 z-20 flex items-end bg-overlay p-4 sm:p-8"
      onPointerDown={() => (holdRef.current = true)} onPointerUp={() => (holdRef.current = false)}>
      <div className="panel mx-auto flex max-h-[85dvh] w-full max-w-3xl gap-3 overflow-y-auto p-4 sm:gap-4" onClick={advance}>
        <div className="portrait-slot shrink-0">{node.portrait}</div>
        <div className="flex min-w-0 flex-1 flex-col">
          <div className="nameplate">{node.speaker}</div>
          <p className="mt-2 min-h-16 font-body text-lg leading-snug">{node.text.slice(0, shown)}</p>
          {done && node.choices && (
            <div className="mt-3 flex flex-col gap-2">
              {node.choices.map((c, i) => (
                <Button variant="game" size="game" key={i} className="choice min-h-12 justify-start whitespace-normal" onClick={(e) => { e.stopPropagation(); choose(i); }}>
                  {i + 1}. {c.text}
                </Button>
              ))}
            </div>
          )}
          {!node.choices && <Button variant="game" size="game" className="choice mt-3 min-h-12 self-end" onClick={(e) => { e.stopPropagation(); advance(); }}>{!done ? "Show text" : node.next ? "Next ▸" : "Continue ▸"}</Button>}
        </div>
      </div>
    </div>
  );
}
