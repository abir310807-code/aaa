import { useEffect, useState } from "react";
import type { CardDef } from "@/game/types";
import { sound } from "@/game/audio";

export function CardView({ card, tilt = true }: { card: CardDef; tilt?: boolean }) {
  const [r, setR] = useState({ x: 0, y: 0 });
  return (
    <div className="perspective-card"
      onMouseMove={(e) => {
        if (!tilt) return;
        const b = e.currentTarget.getBoundingClientRect();
        setR({ x: ((e.clientY - b.top) / b.height - 0.5) * -20, y: ((e.clientX - b.left) / b.width - 0.5) * 24 });
      }}
      onMouseLeave={() => setR({ x: 0, y: 0 })}>
      <img src={card.image} alt={card.name} className="game-card"
        style={{ transform: `rotateX(${r.x}deg) rotateY(${r.y}deg)` }} />
    </div>
  );
}

export function CardAward({ card, onCollect }: { card: CardDef; onCollect: () => void }) {
  useEffect(() => { sound.fanfare(); }, []);
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-5 bg-overlay-strong">
      <p className="eyebrow">Card unlocked · #{String(card.id).padStart(2, "0")}</p>
      <div className="animate-card-in"><CardView card={card} /></div>
      <div className="text-center">
        <h2 className="font-display text-3xl">{card.name}</h2>
        <p className="mt-1 italic text-muted-foreground">{card.flavor}</p>
      </div>
      <button className="btn-game" onClick={() => { sound.click(); onCollect(); }}>Collect</button>
    </div>
  );
}
