import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Boot, Credits, LevelSelect, Options, Vault } from "@/components/game/Screens";
import { LevelView } from "@/components/game/LevelView";
import { getCompleted, getVault } from "@/game/storage";
import { unlockAudio } from "@/game/audio";

export const Route = createFileRoute("/")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Card Collector — a tiny diorama game" },
      { name: "description", content: "Walk tiny dioramas, talk to locals, and collect a card from every level." },
      { property: "og:title", content: "Card Collector" },
      { property: "og:description", content: "Walk tiny dioramas, talk to locals, and collect a card from every level." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Game,
});

type Screen = "boot" | "select" | "vault" | "options" | "credits" | "level";

function Game() {
  const [screen, setScreen] = useState<Screen>("boot");
  const [completed, setCompleted] = useState<number[]>([]);
  const [vault, setVault] = useState<number[]>([]);
  const [all, setAll] = useState(false);
  const [levelId, setLevelId] = useState(1);

  const refresh = () => { setCompleted(getCompleted()); setVault(getVault()); };
  useEffect(() => {
    refresh();
    setAll(new URLSearchParams(window.location.search).get("all") === "1");
    const u = () => unlockAudio();
    window.addEventListener("pointerdown", u, { once: true });
    window.addEventListener("keydown", u, { once: true });
  }, []);

  const go = (s: Screen) => { refresh(); setScreen(s); };

  switch (screen) {
    case "boot": return <Boot go={go} />;
    case "select": return <LevelSelect completed={completed} all={all} onPlay={(id) => { setLevelId(id); setScreen("level"); }} onBack={() => go("boot")} />;
    case "vault": return <Vault vault={vault} onBack={() => go("boot")} />;
    case "options": return <Options onBack={() => go("boot")} />;
    case "credits": return <Credits onBack={() => go("boot")} />;
    case "level": return <LevelView key={levelId} levelId={levelId} onExit={() => go("select")} />;
  }
}
