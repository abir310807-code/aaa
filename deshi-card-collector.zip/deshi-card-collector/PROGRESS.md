# Card Collector — Progress

Stack note: built with React + three.js (user chose this over vanilla/no-build). Plain three.js driven imperatively, no R3F.

## Levels
- [x] 1 — The Kiosk Street (Arjun & Shanti dialogue, Banglish script; Old Tomas = flavor). Flag `l1_paper_bought`.
- [x] 2 — The Air Shot (smokers dialogue, 2 air shots, scatter)
- [x] 3 — The 10 on 10 She (Leader talks to pole, carries it away)
- [x] 4 — The Hisab (salam clip, lathi/chada choice, Akkash chases them off)
- [x] 5 — The Foothpath (rickshaw crash, Patla/Jasim argument, timed car hit, Footpath Card)

## Cards wired
- card_01 "Family Card" → level 1 (user-supplied photo, CDN asset src/assets/family_card.png.asset.json)
- card_02 Anti-Drug Card → L2, card_03 Electricity Card → L3
- card_04 Chanda Card → L4; card_05 Footpath Card → L5 (user-supplied photo, CDN asset)

## Storage (localStorage)
- cc_vault (card ids), cc_completed (level ids), cc_audio (sliders + mute)

## Open TODOs
- Portraits are labeled placeholder slots (P-01…P-15)

## Known bugs
- None known. Feel/framerate/sound not verifiable in sandbox (no GPU/speakers).
